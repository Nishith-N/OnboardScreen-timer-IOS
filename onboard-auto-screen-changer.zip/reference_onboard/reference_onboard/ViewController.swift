//
//  ViewController.swift
//  reference_onboard
//
//  Created by Anilkumar on 21/06/22.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
   
    @IBOutlet weak var myLayout: UICollectionViewFlowLayout!
    var myLabelContent = ["Decorate your design products with relevant shapes. Use basic geometric shapes like squares, circles or more complex shapes such as hearts, stars, bubbles to draw attention to your design segments!","Use arrows, lines, and illustrations to make unique visuals every time. Shapes may look simplistic and even basic, but they're a great addition to your designs. Dont get carried away, though! Too man shapes can overcomplicate your design.","Geometric makes it very easy to animate any design object. There are animation presets that allow you to make a shape zoom, fade, wabble, shake, spin and more, with just a click of a button."]

    @IBOutlet weak var myCollectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setTimer()
        
        view.backgroundColor = .lightGray
        myCollectionView.delegate = self
        myCollectionView.dataSource = self
        
        myLayout.minimumInteritemSpacing = 0
        myLayout.minimumLineSpacing = 0
        
        // Do any additional setup after loading the view.
    }
    
    func setTimer() {
         let _ = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(ViewController.autoScroll), userInfo: nil, repeats: true)
    }
    var x = 1
    @objc func autoScroll() {
        if self.x < self.myLabelContent.count {
          let indexPath = IndexPath(item: x, section: 0)
          self.myCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
          self.x = self.x + 1
        }else{
          self.x = 0
          self.myCollectionView.scrollToItem(at: IndexPath(item: 0, section: 0), at: .centeredHorizontally, animated: true)
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: myCollectionView.frame.width, height: myCollectionView.frame.height)
        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "myCustomCollectionViewCell", for: indexPath) as! myCustomCollectionViewCell
        
        cell.widthAnchor.constraint(equalToConstant: myCollectionView.frame.width).isActive = true
        cell.heightAnchor.constraint(equalToConstant: myCollectionView.frame.height).isActive = true
       
   
        
        if indexPath.row == 0
        {
        
            cell.contentView.backgroundColor = UIColor(red: 216.0/255.0, green: 207.0/255.0, blue: 253.0/255.0, alpha: 1.0)
            cell.myText.backgroundColor = UIColor(red: 216.0/255.0, green: 207.0/255.0, blue: 253.0/255.0, alpha: 1.0)
            cell.myText.text = myLabelContent[indexPath.row]
            cell.myLabel.text = "Use shapes to\n decorate your designs"
            cell.myLabel.font = UIFont.boldSystemFont(ofSize: 25)
            
            
        }
        
        if indexPath.row == 1
        {
            cell.contentView.backgroundColor = UIColor(red: 199.0/255.0, green: 224.0/255.0, blue: 244.0/255.0, alpha: 1.0)
            cell.myText.backgroundColor = UIColor(red: 199.0/255.0, green: 224.0/255.0, blue: 244.0/255.0, alpha: 1.0)
            cell.myText.text = myLabelContent[indexPath.row]
            cell.myLabel.text = "Combine shapes with\n other objects"
            cell.myLabel.font = UIFont.boldSystemFont(ofSize: 25)
        }
        
        if indexPath.row == 2
        {
            cell.contentView.backgroundColor = UIColor(red: 239.0/255.0, green: 217.0/255.0, blue: 203.0/255.0, alpha: 1.0)
            cell.myText.backgroundColor = UIColor(red: 239.0/255.0, green: 217.0/255.0, blue: 203.0/255.0, alpha: 1.0)
            cell.myText.text = myLabelContent[indexPath.row]
            cell.myLabel.text = "Animate shapes to\n catch the attention"
            cell.myLabel.font = UIFont.boldSystemFont(ofSize: 25)
        }
        
        cell.nextBtn.backgroundColor = .white
        cell.nextBtn.layer.cornerRadius = 25.0
        cell.nextBtn.clipsToBounds = true
        
        return cell
    }
    


}

