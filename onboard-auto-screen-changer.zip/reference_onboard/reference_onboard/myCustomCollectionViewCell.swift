//
//  myCustomCollectionViewCell.swift
//  reference_onboard
//
//  Created by Anilkumar on 21/06/22.
//

import UIKit

class myCustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var skipBtn: UIButton!
    @IBOutlet weak var myLabel: UILabel!
    @IBOutlet weak var myText: UITextView!
}
